/*===============================================================
*   Copyright (C) 2020 All rights reserved.
*   
*   文件名称：ser.c
*   创 建 者：郑文杰
*   创建日期：2020年09月08日
*   描    述：客户端
*
*   更新日志：
*
================================================================*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sqlite3.h>
#include <signal.h>
#include <time.h>
#define N 32
#define NN 128
#define Q 1 //普通登录
#define W 2 //普通注册
#define E 3 //管理员登录
#define R 4 //删除
#define T 5 //退出程序 
#define Y 6 //历史查询
#define U 7 //信息查询
#define I 8 //信息修改
#define O 9 //密码修改
#define P 10 //增加 
typedef struct{
    int type;//操作号
    char id[N];  //员工用户名
    char password[N];   //员工用户密码
    char name[N];//姓名
    int age ;  //年龄
    char gender[N];//性别
    char phone[N];//手机号
    int wage;//工资
    int  seniority;//年资
    char cw[N];//传递信息
    int ii;//传递int信息
    char jj[N];//传递char信息
    int a;//选项 0是char  1是int
}MSG;

typedef struct record{
	char id[N];
	char login_info[N];
	char cw[N];
}INFO;

INFO info_meg;



//------------------------僵尸进程处理函数--------
void handler(int arg)
{
    wait(NULL);
}


//----------------------------------函数声明-------------------
//普通用户登录
void my_up(MSG *msg,sqlite3 *db,int clifd);

//普通用户注册
void my_in(MSG *msg,sqlite3 *db,int clifd);

//管理员登录
void root_up(MSG*msg,sqlite3 *db,int clifd);

//删除成员
void my_del(MSG *msg,sqlite3 *db,int clifd);

//历史查询
void my_history(MSG *msg,sqlite3 *db,int clifd);

//信息查询
void my_message(MSG *msg,sqlite3 *db,int clifd);

//信息修改
void my_amend(MSG *msg,sqlite3 *db,int clifd);

//新增成员
void my_new(MSG *msg,sqlite3 *db,int clifd);

//密码修改
void my_password(MSG *msg,sqlite3 *db,int clifd);
//
//----------------------主函数体---------------------------
int main(int argc, const char *argv[])
{
    int sockfd = 0;
    int clifd =0;
    int len = 0;
    ssize_t ret = 0;
    MSG msg;
    int my_db=0;
    sqlite3 *db = NULL;
    pid_t pid;
//----------------操作数据库------------------------
    my_db = sqlite3_open("./my.db",&db);
    if(my_db != 0)
    {
        printf("数据库打开失败\n");
        return -1;    
    }
	 char *errmsg = NULL;
	 char *create_table_history = "create table if not exists user_history('id' text,'record' text);";
	 if(sqlite3_exec(db,create_table_history,NULL,NULL,&errmsg)!=SQLITE_OK){
		       printf("%s\n",errmsg);
		       sqlite3_close(db);                                                                             
		 }else{
			      printf("员工登录历史记录创建完成！\n");
			      }




//---------------------TCP搭建------------------------
    //创建套接子；
    sockfd = socket(AF_INET,SOCK_STREAM,0);
    if(sockfd == -1)
    {
        perror("socket");
        return -1;
    }
    printf("套接子创建成功\n");//调试使用
    //套接字绑定
    struct sockaddr_in ser,cli;//地址信息结构体
    ser.sin_family = AF_INET;           //采用的协议族类型
    ser.sin_port   = htons(6666);        //网络端口号
    ser.sin_addr.s_addr = inet_addr("0.0.0.0");     //自动ip地址

    if(bind(sockfd,(struct sockaddr *)&ser,sizeof(ser)) == -1)
    {
        perror("bind");
        close(sockfd);
        return -1;
    }

    //监听套接子
    if(listen(sockfd,10) < 0)     //服务器可以同时监听客户端的个数
    {
        perror("listen");
        close(sockfd);
        return -1;
    }
    len = sizeof(cli);
    signal(SIGCHLD,handler);//僵尸进程处理函数
    while(1)
    {
        clifd = accept (sockfd,(struct sockaddr *)&cli,&len);
        if(clifd < 0)
        {
            perror("accept");
            return -1;
        }
        pid = fork(); //多线程
        if(pid< 0 )
        {
            perror("fork");
            return -1;
        }
        else if(pid == 0) //子进程
        {
            close (sockfd);        //关闭子进程的监听套接子

            while(1)
            {
                memset(&msg,0,sizeof(MSG));
                printf("-------------------------");
                ret = recv(clifd,&msg,sizeof(msg),0);     //读取客户端发送过来的结构体
                printf("%d\n",msg.type);
                if (ret <=0)
                {
                    break;
                }
                switch(msg.type)
                {
                    case Q:
                        //普通用户登录
                        printf("进入选择界面执行选择函数\n");
                        my_up(&msg,db,clifd);
                        break;
                    case W:
                        //普通用户注册
                        my_in(&msg,db,clifd);
                        break;
                    case E:
                        //管理员登录
                        root_up(&msg,db,clifd);
                        break;
                    case R:
                        //删除
                        my_del(&msg,db,clifd);
                        break;
                    case T:
                        //退出程序
                        break;
                    case Y:
                        //历史查询
                        my_history(&msg,db,clifd);
                        break;
                    case U:
                        //信息查询
                        my_message(&msg,db,clifd);
                        break;
                    case I:
                        //信息修改
                        my_amend(&msg,db,clifd);
                        break;
                    case O:
                        //密码修改
                        my_password(&msg,db,clifd);
                        break;
                    case P:
                        //新增成员
                        my_new(&msg,db,clifd);
                        break;

                    default:

                        break;
                }
    }
    }else
    {
        close (clifd);
    
    }
    }
    return 0;
}

//------------------------------函数声明----------------------
//普通用户登录
void my_up(MSG *msg,sqlite3 *db,int clifd)
{
    printf("进入用户登录界面");
    char sql[128]={0};
    char ** res;//查询结果
    int m=0;//行数
    int n=0;//列数
    char * error;
    sprintf(sql,"select * from user where id = '%s' and password = '%s';",msg->id,msg->password);
    printf ("%s",sql);
    if (sqlite3_get_table(db,sql,&res,&m,&n,&error) != 0)
    {
        printf("没有查询结果");
        strcpy(msg->cw,"无此成员");   
    }
    if(m>0)//说明查询有结果
    {
    printf("有查询结果");
    memset(msg,0,sizeof(msg));
    strcpy(msg->cw,"ok");
   /* int i =0;
    int nn=n;
    for (i=0;i<m;i++)
    {
    if(i = 0)
        strcpy(msg->id,res[nn++]);//取出用户名
    if(i = 1)
        strcpy(msg->password,res[nn++]);//取出密码
    if(i = 2)
        strcpy(msg->name,res[nn++]);//取出姓名
    if(i = 3)
        msg->age = atoi(res[nn++]);//取出年龄
    if(i = 4)
        strcpy(msg->gender ,res[nn++]);//取出性别
    if(i = 5)
        msg->age = atoi(res[nn++]);//取出手机号
    if(i = 6)
        msg->wage = atoi(res[nn++]);//取出工资
    if(i = 7)
        msg->seniority = atoi(res[nn++]);//取出年资
    }*/
    }
    if (send(clifd,msg,sizeof(MSG),0) <0)
    {
        perror("send");
        exit(-1);   
    }
	 time_t t = time(NULL);
	     struct tm *tp;
	    tp = localtime(&t);
	    char time_c[128] = "";
	    sprintf(time_c,"%d-%d-%d %d:%d:%d",tp->tm_year + 1900,tp->tm_mon+1,tp->tm_mday,tp->tm_hour,tp->tm_min,tp->tm_sec);
		     printf("%s\n",time_c);
		     sprintf(sql,"insert into user_history values('%s','%s');",msg->id,time_c);
		     if(sqlite3_exec(db,sql,NULL,NULL,&error)!= SQLITE_OK){
		         fprintf(stderr,"插入:%s\n",error);
			         sqlite3_close(db);
			 
			     }else
			          puts("插入成功\n");



}

//普通用户注册
void my_in(MSG *msg,sqlite3 *db,int clifd)
{
    char *error;
   char sql[128]={0};
   //封装语句
   sprintf(sql,"insert into user values('%s','%s','%s',%d,'%s','%s',%d,%d);",msg->id,msg->password,msg->name,msg->age,msg->gender,msg->phone,msg->wage,msg->seniority);
    printf("调试语句：%s\n",sql) ;
    if (sqlite3_exec(db,sql,NULL,NULL,&error) != SQLITE_OK)
    {
        printf("%s\n",error);
        strcpy(msg->cw,"err");
    }
    else 
    {
        printf("用户注册成功");
        strcpy(msg->cw,"ok");    
    }

    if(send(clifd,msg,sizeof(MSG),0) < 0)
    {
    printf("发送失败");
    }
}

//管理员登录
void root_up(MSG*msg,sqlite3 *db,int clifd)
{
    char * err;
    char sql[128]={0};
    int n,m;
    char ** res;
    sprintf(sql,"select * from root where user ='%s' and password='%s';",msg->id,msg->password);
    if(sqlite3_get_table(db,sql,&res,&m,&n,&err)!=0)
    {
        printf("没有查询到结果\n");
        strcpy(msg->cw,"无此成员");
    }
    if(m>0)
    {
        printf("有查询结果\n");
        memset(msg,0,sizeof(msg));
        strcpy(msg->cw,"ok");
    }
    if (send(clifd,msg,sizeof(MSG),0) < 0)
    {
        printf("发送失败\n");
    }

}
int callback_history(void *para,int f_num,char **f_value,char **f_name)
{
	int clifd;
	clifd = *((int *)para);
	printf("clifd = %d\n",clifd);
	memset(&info_meg,0,sizeof(INFO));
	strcpy(info_meg.id,f_value[0]);
	strcpy(info_meg.login_info,f_value[1]);
	printf("%s ",info_meg.id);
	printf("%s \n",info_meg.login_info);
  // sleep(1); 
	if(send(clifd,&info_meg,sizeof(INFO),0) < 0){
		perror("send");
		return -1;
	}else
	{
		printf("---------\n");
	}
	return 0;

}

//历史查询
void my_history(MSG *msg,sqlite3 *db,int clifd)
{
	char *error;
	char sql[123] = {0};
		sprintf(sql,"select * from user_history where id='%s';",msg->id);
		if(sqlite3_exec(db,sql,callback_history,&clifd,&error)!= SQLITE_OK){
			printf("没有查询到结果\n");

		}else{
		  		puts("查询成功");
							

		}
	strcpy(info_meg.cw,"quit");
	if(send(clifd,&info_meg,sizeof(INFO),0) < 0){
		perror("send");
	}else{
		printf("quit\n");
	}

}


//信息查询
void my_message(MSG *msg,sqlite3 *db,int clifd)
{
    char *error;

    char sql[123]={0};
    int n=0;
    int m=0;
    char **res;
    sprintf(sql,"select * from user where id='%s';",msg->id);
    if (sqlite3_get_table(db,sql,&res,&m,&n,&error) != SQLITE_OK)
    {
        printf("没有查询结果");
        strcpy(msg->cw,"无此成员");   
    }
    if(m>0)//说明查询有结果
    {
    memset(msg,0,sizeof(MSG));
     printf ("进入提取模块\n");
    strcpy(msg->cw,"ok");
  //  int i =0;
    int nn=n;
 //   for (i=0;i<n;i++)
 //   {
  //  if(i = 0)
        strcpy(msg->id,res[nn++]);//取出用户名
 //   if(i = 1)i
        printf("===========%s\n",msg->id);
        strcpy(msg->password,res[nn++]);//取出密码
        printf("===========%s\n",msg->password);
 //   if(i = 2)
        strcpy(msg->name,res[nn++]);//取出姓名
        printf("===========%s\n",msg->name);
 //   if(i = 3)
        msg->age = atoi(res[nn++]);//取出年龄
        printf("===========%d\n",msg->age);
  //  if(i = 4)
        strcpy(msg->gender ,res[nn++]);//取出性别
        printf("===========%s\n",msg->gender);
  //  if(i = 5)
       strcpy( msg->phone ,res[nn++]);//取出手机号
        printf("===========%d\n",msg->age);
  //  if(i = 6)
        msg->wage = atoi(res[nn++]);//取出工资
        printf("===========%d\n",msg->wage);
 //   if(i = 7)
        msg->seniority = atoi(res[nn++]);//取出年资
        printf("===========%d\n",msg->seniority);
 //   }
 //
    
    }
printf("------------------发送----------\n");
    if (send(clifd,msg,sizeof(MSG),0) <0)
    {
        perror("send");


    }
}

//信息修改
void my_amend(MSG *msg,sqlite3 *db,int clifd)
{
    char *err;
    char sql[123];
    if(msg->a ==0)
    {
    sprintf(sql,"update user set '%s'='%s'where id='%s';",msg->cw,msg->jj,msg->id);
    }
    else if(msg->a ==1)
    {
    sprintf(sql,"update user set '%s'=%d where id='%s';",msg->cw,msg->ii,msg->id); 
    }
    if(sqlite3_exec(db,sql,NULL,NULL,&err) != SQLITE_OK)
    {
        printf("修改失败\n");
        strcpy(msg->cw,"err");
    }
    else
    {
        strcpy(msg->cw,"ok");
    }
    if (send(clifd,msg,sizeof(MSG),0) < 0)
    {
        printf("发送失败\n");
    }

}

//新增成员
void my_new(MSG *msg,sqlite3 *db,int clifd)
{
    char *err;
    char sql[123]={0};

   sprintf(sql,"insert into user values('%s','%s','%s',%d,'%s','%s',%d,%d);",msg->id,msg->password,msg->name,msg->age,msg->gender,msg->phone,msg->wage,msg->seniority);
    printf("调试语句：%s\n",sql) ;
    if (sqlite3_exec(db,sql,NULL,NULL,&err) != SQLITE_OK)
    {
        printf("%s\n",err);
        strcpy(msg->cw,"用户名存在");
    }
    else 
    {
        printf("用户注册成功");
        strcpy(msg->cw,"ok");    
    }

    if(send(clifd,msg,sizeof(MSG),0) < 0)
    {
    printf("发送失败");
    }
}
//删除成员
void my_del(MSG *msg,sqlite3 *db,int clifd)
{
    char * err;
    char sql[123]={0};
    sprintf(sql,"delete from user where name='%s';",msg->id);
    if( sqlite3_exec(db,sql,NULL,NULL,&err)!= SQLITE_OK)
    {
        strcpy(msg->cw,"error");
    }
    else
    {
        strcpy(msg->cw,"ok");

    }
    if (send(clifd,msg,sizeof(MSG),0) < 0)
    {
        printf("发送失败\n");
    }
} 
//密码修改
void my_password(MSG *msg,sqlite3 *db,int clifd)
{
    char *err;
    char sql[123];
    sprintf(sql,"update user set password='%s' where id='%s';",msg->cw,msg->id);
    printf("调试语句%s\n",sql);
    if(sqlite3_exec(db,sql,NULL,NULL,&err) != SQLITE_OK)
    {
        printf("修改失败\n");
        strcpy(msg->cw,"err");
    }
    else
    {
        strcpy(msg->cw,"ok");
    }
    if (send(clifd,msg,sizeof(MSG),0) < 0)
    {
        printf("发送失败\n");
    }

}
