/*===============================================================
*   Copyright (C) 2020 All rights reserved.
*   
*   文件名称：dict_client.c
*   创 建 者：Zhangbin
*   创建日期：2020年07月16日
*   描    述：
*
*   更新日志：
*
================================================================*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#define SEVIP "0.0.0.0"  //服务器ip
#define PORT 6666      //端口号
#define N 32

typedef struct message
{
    int type;//操作号
    char id[N];  //员工用户名
    char password[N];   //员工用户密码
    char name[N];//姓名
    int age ;  //年龄
    char gender[N];//性别
    char phone[N];//手机号
    int wage;//工资
    int  seniority;//年资
    char cw[N];//传递信息
    int ii;//传递int信息
    char jj[N];//传递char信息
    int a;//选项 0是char  1是int
}MEG;

typedef struct record{
	char id[N];//员工用户名
	char login_info[N];//员工登录的历史记录
	char cw[N];
}INFO;


int sockfd;
int flag=0;
MEG sd_meg;
MEG recv_meg;
char user[N];
char passwd[N];
INFO info_meg;

//函数的声明
int do_register(MEG *send_meg);
int do_login(MEG *send_meg);
int do_super_login(MEG *send_meg);
int search_information(MEG *send_meg);
int change_password(MEG *send_meg);
int update_information(MEG *send_meg);
int add_user(MEG *send_meg);
int delete_user(MEG *send_meg);
int update_user_information(MEG *send_meg);


int main()
{
    //创建套接字
    sockfd = socket(AF_INET,SOCK_STREAM,0);
    if(sockfd == -1)
    {
        perror("socket");
        return -1;
    }

    //设置服务器的ip，端口号
    struct sockaddr_in sev_addr;
    sev_addr.sin_family = AF_INET;
    sev_addr.sin_port = htons(PORT);
    sev_addr.sin_addr.s_addr = inet_addr(SEVIP);
//连接服务器
    if(connect(sockfd,(struct sockaddr*)&sev_addr,sizeof(sev_addr))==-1)
    {
        perror("connect");
        return -1;
    }
    int cmd=0;
//登录界面
    while(1)
    {
        printf("**********************************************************************\n");
        printf("************1:注册 2.普通用户登录  3.超级用户登录  4.退出 ************\n");
        printf("**********************************************************************\n");
        printf("Please choose:");
        scanf("%d",&cmd);
        getchar();
        switch (cmd)
        {
            case 1:
                if(do_register(&sd_meg) == -1)
                {
                    printf("do_register failed\n");
                }
                break;
            case 2:
                if(do_login(&sd_meg) == 1)
                {
                    goto user;
                }
                break;
            case 3:
                if(do_super_login(&sd_meg) == 1)
                {
                    goto superuser;
                }
                break;
            case 4:
                close(sockfd);
                exit(0);
        }
    //    system("clear");
    }
//普通用户界面
    while(1)
    {
user:
        printf("*********************************************************\n");
        printf("******1:查询信息 2.修改密码 3.修改个人信息 4.退出 *******\n");
        printf("*********************************************************\n");
        printf("Please choose:");
        scanf("%d",&cmd);  //如果下一个接收的是字符则必须需要加getchar()
        switch (cmd)
        {
            case 1:
                flag=0;
                search_information(&sd_meg);
                break;
            case 2:
                change_password(&sd_meg);
                break;
            case 3:
                update_information(&sd_meg);
                break;
            case 4:
                close(sockfd);
                exit(0);
        }
      //  system("clear");
    }
//超级用户界面
    while(1)
    {
superuser:
        printf("************************************************************************************\n");
        printf("******1:添加用户 2.删除用户 3.修改用户信息 4.查询用户信息 5.查询历史  6.退出 *******\n");
        printf("************************************************************************************\n");
        printf("Please choose:");
        scanf("%d",&cmd);  //如果下一个接收的是字符则必须需要加getchar()
        switch (cmd)
        {
            case 1:
                do_register(&sd_meg);
                break;
            case 2:
                delete_user(&sd_meg);
                break;
            case 3:
                update_user_information(&sd_meg);
                break;
            case 4:
                flag=1;
                search_information(&sd_meg);
                break;
            case 5:
				search_history(&sd_meg);
                break;
            case 6:
                close(sockfd);
                exit(0);
        }
       // system("clear");
    }
    return 0;
}

//清空结构体数据包
void struct_clear(MEG * m)
{
    int i;
    m->type=0;
    m->age=0;
    m->seniority=0;
    memset(m->id,0,N);
    memset(m->password,0,N);
    memset(m->name,0,N);
    memset(m->gender,0,N);
    memset(m->cw,0,N);
    memset(m->phone,0,N);
    m->wage=0;
}


//注册函数
int do_register(MEG *send_meg)
{
        //打包数据，发送数据
        struct_clear(send_meg);
        send_meg->type = 2;
        printf("请输入用户名：\n");
        scanf("%s",send_meg->id);
        printf("请输入密码：\n");
        scanf("%s",send_meg->password);
        printf("请输入姓名：\n");
        scanf("%s",send_meg->name);
        printf("请输入年龄：\n");
        scanf("%d",&send_meg->age);
        printf("请输入性别：\n");
        scanf("%s",send_meg->gender);
        printf("请输入手机号：\n");
        scanf("%s",send_meg->phone);
        printf("请输入工资：\n");
        scanf("%d",&send_meg->wage);
        printf("请输入年薪：\n");
        scanf("%d",&send_meg->seniority);
        //发送数据包
        if(write(sockfd,send_meg,sizeof(MEG)) ==-1)
        { 
            perror("write");
            return -1;
        }
        //接收反馈
        struct_clear(&recv_meg);
        if(-1 ==read(sockfd,&recv_meg,sizeof(recv_meg)))
        { 
            perror("read");
            return -1;
        }
        //判断反馈结果并回显
        if(strncmp(recv_meg.cw,"ok",2) != 0)
        {
            printf("用户名已存在\n");
        }
        else
        {
            printf("注册成功\n");
        }
        return 0;
}

//普通用户登录
int do_login(MEG *send_meg)
{
    //打包数据
    struct_clear(send_meg);
    send_meg->type =1;
    printf("请输入用户名：\n");
    scanf("%s",send_meg->id);
    getchar();
    printf("请输入密码：\n");
    scanf("%s",send_meg->password);
    getchar();
    //发送数据包
    if(-1 ==write(sockfd,send_meg,sizeof(MEG)))
    { 
        perror("write");
        return -1;
    }
    //接收反馈
    struct_clear(&recv_meg);
    if(-1 ==read(sockfd,&recv_meg,sizeof(recv_meg)))
    { 
        perror("read");
        return -1;
    }

    printf("-----------接收成功-------------------\n");
    printf("%s\n",recv_meg.cw);
    if(strncmp(recv_meg.cw,"ok",2) == 0)
    {
        printf("登录成功\n");
        memset(user,0,N);
        strcpy(user,send_meg->id);
        memset(passwd,0,N);
        strcpy(passwd,send_meg->password);
        return 1; 
    }
    else
    {
        printf("密码错误\n");
        return 0;
    }
}

//超级用户登录
int do_super_login(MEG *send_meg)
{
    //打包数据
    struct_clear(send_meg);
    send_meg->type =3;
    printf("请输入用户名：\n");
    scanf("%s",send_meg->id);
    printf("请输入密码：\n");
    scanf("%s",send_meg->password);
    //发送数据包
    if(-1 ==write(sockfd,send_meg,sizeof(MEG)))
    { 
        perror("write");
        return -1;
    }
    //接收反馈
    struct_clear(&recv_meg);
    if(-1 ==read(sockfd,&recv_meg,sizeof(recv_meg)))
    { 
        perror("read");
        return -1;
    }
    printf("%s\n",recv_meg.cw);
    if(strncmp(recv_meg.cw,"ok",2) == 0)
    {
        printf("登录成功\n");
        return 1; 
    }
    else
    {
        printf("密码错误\n");
        return 0;
    }
}

//查询个人信息
int search_information(MEG *send_meg)
{
    struct_clear(send_meg);
    send_meg->type=7;
    if(flag==0)
    {
        strcpy(send_meg->id,user);
    }
    else if(flag ==1)
    {
        printf("请输入要查询的用户名：");
        scanf("%s",send_meg->id);
    }
    //发送包装好的结构体
    if(-1 ==write(sockfd,send_meg,sizeof(MEG)))
    { 
        perror("write");
        return -1;
    }
    //接收信息
    struct_clear(&recv_meg);
    if(-1 ==read(sockfd,&recv_meg,sizeof(MEG)))
    { 
        perror("read");
        return -1;
    }
    //打印信息
    if(strcmp(recv_meg.cw,"ok")!=0)
        printf("无此用户\n");
    else
        printf("id=%s\nname=%s\nage=%d\ngender=%s\nphone=%s\nwage=%d\nseniority=%d\n",recv_meg.id,recv_meg.name,recv_meg.age,recv_meg.gender,recv_meg.phone,recv_meg.wage,recv_meg.seniority); 
    return 0;
}

//修改密码
int change_password(MEG *send_meg)
{
    
    struct_clear(send_meg);
    send_meg->type=9;
    printf("请输入旧密码:");
    scanf("%s",send_meg->password);
    if(strcmp(send_meg->password,passwd)!=0)
    {
        printf("输入密码错误\n");
        return 0;
    }
    printf("请输入新密码:");
    scanf("%s",send_meg->cw);
    strcpy(send_meg->id,user);
    //发送包装好的结构体
    if(-1 ==write(sockfd,send_meg,sizeof(MEG)))
    { 
        perror("write");
        return -1;
    }
     //接收反馈
    struct_clear(&recv_meg);
    if(-1 ==read(sockfd,&recv_meg,sizeof(recv_meg)))
    { 
        perror("read");
        return -1;
    }
    printf("-----------接收成功-------------------\n");
    printf("%s\n",recv_meg.cw);
    if(strncmp(recv_meg.cw,"ok",2) == 0)
    {
        printf("修改密码成功\n");
    }
    else
    {
        printf("修改密码失败\n");
    }

    return 0;
}

//修改个人信息
int update_information(MEG *send_meg)
{
    int cmd;
    struct_clear(send_meg);
    strcpy(send_meg->id,user);
    send_meg->type=8;
    while(1)
    {
        printf("*****************************************************************\n");
        printf("****** 1.姓名 2.年龄 3.性别 4.手机号 5.工资 6.年资 7.退出 *******\n");
        printf("*****************************************************************\n");
        printf("Please choose:");
        scanf("%d",&cmd);  //如果下一个接收的是字符则必须需要加getchar()
        switch (cmd)
        {
            case 1:
                printf("请输入新的姓名：");
                scanf("%s",send_meg->jj);
                send_meg->a=0;
                strcpy(send_meg->cw,"name");
                break;
            case 2:
                printf("请输入新的年龄：");
                scanf("%d",&send_meg->ii);
                send_meg->a=1;
                strcpy(send_meg->cw,"age");
                break;
            case 3:
                printf("请输入新的性别：");
                scanf("%s",send_meg->jj);
                send_meg->a=0;
                strcpy(send_meg->cw,"gender");
                break;
            case 4:
                printf("请输入新的手机号：");
                scanf("%s",send_meg->jj);
                send_meg->a=0;
                strcpy(send_meg->cw,"phone");
                break;
            case 5:
                printf("请输入新的工资：");
                scanf("%d",&send_meg->ii);
                send_meg->a=1;
                strcpy(send_meg->cw,"wage");
                break;
            case 6:
                printf("请输入新的年资：");
                scanf("%d",&send_meg->ii);
                send_meg->a=1;
                strcpy(send_meg->cw,"seniority");
                break;
            case 7:
                return 0;
        }
        //发送包装好的结构体
        if(-1 ==write(sockfd,send_meg,sizeof(MEG)))
        { 
            perror("write");
            return -1;
        }
        //接收反馈
        struct_clear(&recv_meg);
        if(-1 ==read(sockfd,&recv_meg,sizeof(recv_meg)))
        { 
            perror("read");
            return -1;
        }
        printf("-----------接收成功-------------------\n");
        printf("%s\n",recv_meg.cw);
        if(strncmp(recv_meg.cw,"ok",2) == 0)
        {
            printf("修改个人信息成功\n");
        }
        else
        {
            printf("修改失败\n");
        }


    }
    return 0;
}

//添加用户
int add_user(MEG *send_meg)
{
    return 0;
}
//删除用户
int delete_user(MEG *send_meg)
{
    char again_id[N];
    struct_clear(send_meg);
    send_meg->type=4;
    printf("请输入删除的用户:");
    scanf("%s",send_meg->id);
    printf("请确认输入删除的用户:");
    scanf("%s",again_id);
    if(strcmp(send_meg->id,again_id))
    {
        printf("输入确认的用户出错\n");
        return -1;
    }
    //发送包装好的结构体
    if(-1 ==write(sockfd,send_meg,sizeof(MEG)))
    { 
        perror("write");
        return -1;
    }
    //接收反馈
    struct_clear(&recv_meg);
    if(-1 ==read(sockfd,&recv_meg,sizeof(recv_meg)))
    { 
        perror("read");
        return -1;
    }
    printf("-----------接收成功-------------------\n");
    printf("%s\n",recv_meg.cw);
    if(strncmp(recv_meg.cw,"ok",2) == 0)
    {
        printf("删除成功\n");
    }
    else
    {
        printf("删除失败\n");
    }

    return 0;
}


//修改用户信息
int update_user_information(MEG *send_meg)
{
    int cmd;
    struct_clear(send_meg);
    send_meg->type=8;
    printf("请输入需要更改的用户名：");
    scanf("%s",send_meg->id);
    while(1)
    {
        printf("*****************************************************************\n");
        printf("****** 1.姓名 2.年龄 3.性别 4.手机号 5.工资 6.年资 7.退出 *******\n");
        printf("*****************************************************************\n");
        printf("Please choose:");
        scanf("%d",&cmd);  //如果下一个接收的是字符则必须需要加getchar()
        switch (cmd)
        {
            case 1:
                printf("请输入新的姓名：");
                scanf("%s",send_meg->jj);
                send_meg->a=0;
                strcpy(send_meg->cw,"name");
                break;
            case 2:
                printf("请输入新的年龄：");
                scanf("%d",&send_meg->ii);
                send_meg->a=1;
                strcpy(send_meg->cw,"age");
                break;
            case 3:
                printf("请输入新的性别：");
                scanf("%s",send_meg->jj);
                send_meg->a=0;
                strcpy(send_meg->cw,"gender");
                break;
            case 4:
                printf("请输入新的手机号：");
                scanf("%d",&send_meg->ii);
                send_meg->a=1;
                strcpy(send_meg->cw,"phone");
                break;
            case 5:
                printf("请输入新的工资：");
                scanf("%d",&send_meg->ii);
                send_meg->a=1;
                strcpy(send_meg->cw,"wage");
                break;
            case 6:
                printf("请输入新的年资：");
                scanf("%d",&send_meg->ii);
                send_meg->a=1;
                strcpy(send_meg->cw,"seniority");
                break;
            case 7:
                return 0;
        }
        //发送包装好的结构体
        if(-1 ==write(sockfd,send_meg,sizeof(MEG)))
        { 
            perror("write");
            return -1;
        }
        //接收反馈
        struct_clear(&recv_meg);
        if(-1 ==read(sockfd,&recv_meg,sizeof(recv_meg)))
        { 
            perror("read");
            return -1;
        }
        printf("-----------接收成功-------------------\n");
        printf("%s\n",recv_meg.cw);
        if(strncmp(recv_meg.cw,"ok",2) == 0)
        {
            printf("修改信息成功\n");
        }
        else
        {
            printf("修改失败\n");
        }

      //  system("clear");
    }
    return 0;

}
//查询某个用户的历史记录
int search_history(MEG *send_meg)
{
	int ret = -1;
	struct_clear(send_meg);
	send_meg->type = 6;//选择查询功能
	printf("请输入要查询的用户名：");
	scanf("%s",send_meg->id);
	//发送信息结构体
	if(-1 == write(sockfd,send_meg,sizeof(MEG)))
	{
		perror("write");
		return -1;
	}
	while(1){
		memset(&info_meg,0,sizeof(INFO));//清空历史记录结构体
		ret =recv(sockfd,&info_meg,sizeof(INFO),0); 	
		if(ret < 0)
		{
			perror("read");
			break;
		}
		if(strncmp(info_meg.cw,"quit",4) == 0){
			return 0;
		}
		printf("%s %s\n",info_meg.id,info_meg.login_info);

	}
	return 0;
}
